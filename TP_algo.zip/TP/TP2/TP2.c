#include <stdio.h>
#include <stdlib.h>

/*  Définition de la structure de noeud  */
struct noeud{
  int valeur;
  struct noeud * suivant;
};

/*  Définition du type liste qui est un pointeur sur noeud  */
typedef struct noeud * liste;

/*  Fonction affichant les valeurs des noeuds d'une liste L  */
void afficheListe(liste L){
  int compteur = 1;
  while(L != NULL){
    printf("Le noeud %d a la valeur %d \n",compteur,L->valeur);
    compteur++;
    L = L->suivant;
  }
  printf("\n");
}

/* Fonction calculant le nombre de noeud d'une liste L  */
int nombreNoeuds(liste L){
	int length = 0;        
	while (L){
		length++;          
		L = L->suivant; 
	}
	printf("Nombre de noeud de la liste : %d \n",length);       
}

/*  nouveauNoeud(x) crée une nouvelle liste contenant un noeud avec la valeur x et le suivant égal à NULL  */
liste nouveauNoeud(int x){
  liste L = malloc(sizeof(liste));  /* ou malloc(sizeof(struct noeud))  */
  L->valeur = x;
  L->suivant = NULL;
  return L;
}

/*  Fonction insérant un nouveau noeud de valeur x au début de la liste L  */
liste insereDebut(liste L, int x){
  liste tmp = nouveauNoeud(x);
  if (L == NULL)
    return tmp;
  else{
    tmp->suivant = L;
    return tmp;
  }
}

/*  Fonction récursive insérant un nouveau noeud de valeur x à la fin de la liste L  */
liste insererFinRec(liste L, int x){

}


/*  Fonction itérative insérant un nouveau noeud de valeur x à la fin de la liste L  */
liste insererFinIt(liste L, int x){
  if (L == NULL)
    return nouveauNoeud(x);
  liste tmp = L;
  while (tmp->suivant != NULL)
    tmp = tmp->suivant;
  tmp->suivant = nouveauNoeud(x);
  return L;
}

/*  Fonction retournant l'adresse (le pointeur sur le noeud) du premier noeud contenant la valeur x.
  On retourne NULL lorsque la liste ne contient pas la valeur x  */
liste rechercheIt(liste L, int x){
  if (L == NULL)
    return NULL;
  liste tmp = L;
  while (tmp != NULL){
    if (tmp->valeur == x)
      return tmp;
    tmp = tmp->suivant;
  }
  return NULL;
}

/*  Fonction insérant un nouveau noeud avec la valeur y après le premier noeud contenant la valeur x.
S'il n'y a pas de noeud contenant la valeur x, cette fonction ne fait rien.  
On utilise la fonction rechercheIt pour déterminer l'adresse du noeud contenant la valeur x  */ 
liste  insereApres(liste L, int x, int y){
  liste tmp = rechercheIt(L, x);
  if (tmp != NULL){
    liste tmp2 = tmp->suivant;
    tmp->suivant = nouveauNoeud(y);
    tmp->suivant->suivant = tmp2;
  }
  return L;
}

/*  Fonction insérant un nouveau noeud avec la valeur y avant le premier noeud contenant la valeur x.
S'il n'y a pas de noeud contenant la valeur x, cette fonction ne fait rien.  
Astuce : on reprend la fonction insereApres et on échange les valeurs x et y  */
liste insereAvant(liste L, int x, int y){
  liste tmp = L;
  if(tmp == NULL){
     return L;
  } 

  if(tmp->suivant == NULL){
     return L;
  }

  while(tmp->suivant->valeur != x){
	tmp = tmp->suivant;
  }

  if (tmp != NULL){
    liste tmp2 = tmp->suivant;
    tmp->suivant = nouveauNoeud(y);
    tmp->suivant->suivant = tmp2;
  }
  return L;
}


/*  A chaque fois que vous écrivez une fonction, testez-la dans le main */

/*  Question 0 dans le main, créez une liste contenant les valeurs 8, 3, 5.  */

/*  Question 1 complétez la fonction nombreNoeuds  */

/*  Question 2 construisez une liste chaînée en utilisant plusieurs fois la fonction insererDebut  */

/*  Question 3 complétez la fonction insererFinRec, testez dans le main 
les fonctions insereFinRec et insererFinIt  */ 

/*  Question 4 examinez le code des fonctions rechercheIt insereApres et 
    complétez la fonction insereAvant  */

int main(){
/*	// Liste chaînée 
	liste l = NULL;	
	for(int i = 0;i<5;i++){
		l = insereDebut(l,i);
	}
	afficheListe(l);
	nombreNoeuds(l);
*/
/*	// Fonction inserFinRec
	liste lc = NULL;
	for(int i = 0;i<10;i++){
		lc = insererFinRec(l,i);
	}
	afficheListe(lc);
	nombreNoeuds(lc);
*/
/*	// Fonction inserFinIt
	liste lc2 = NULL;
	for(int i = 0;i<10;i++){
		lc2 = insererFinIt(l,i);
	}
	afficheListe(lc2);
	nombreNoeuds(lc2);
*/
	// Fonction InservApres
	liste l1 = NULL;	
	for(int i = 0;i<5;i++){
		l1 = insereDebut(l1,i);
	}
	afficheListe(insereApres(l1,0,500));
	nombreNoeuds(l1);

	// Fonction InservAvant
	liste l = NULL;	
	for(int i = 0;i<5;i++){
		l = insereDebut(l,i);
	}
	afficheListe(insereAvant(l,0,500));
	nombreNoeuds(l);

}

